from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from contextlib import asynccontextmanager
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from database import init_db, get_db
from routers import pilotos, voos, incidentes, relatorios, auth
import sqlite3

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="RPAS Offshore Ranking API",
    description="Sistema de ranking de pilotos RPAS para operações offshore em P&G",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth", tags=["Autenticação"])
app.include_router(pilotos.router, prefix="/api/pilotos", tags=["Pilotos"])
app.include_router(voos.router, prefix="/api/voos", tags=["Voos"])
app.include_router(incidentes.router, prefix="/api/incidentes", tags=["Incidentes"])
app.include_router(relatorios.router, prefix="/api/relatorios", tags=["Relatórios"])

frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=os.path.join(frontend_path, "css")), name="css_static")
    app.mount("/js", StaticFiles(directory=os.path.join(frontend_path, "js")), name="js_static")

@app.get("/", response_class=FileResponse)
async def root():
    index = os.path.join(frontend_path, "index.html")
    if os.path.exists(index):
        return FileResponse(index)
    return JSONResponse({"status": "API RPAS Ranking rodando", "docs": "/docs"})

@app.get("/piloto/{piloto_id}", response_class=FileResponse)
async def piloto_page(piloto_id: int):
    page = os.path.join(frontend_path, "piloto.html")
    if os.path.exists(page):
        return FileResponse(page)
    return JSONResponse({"piloto_id": piloto_id})

@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}

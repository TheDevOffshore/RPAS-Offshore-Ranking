from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import sqlite3
from database import get_db
from datetime import datetime

router = APIRouter()

WEIGHTS = {
    "tecnica_voo": 0.25,
    "seguranca": 0.25,
    "regulatorio": 0.15,
    "trabalho_equipe": 0.10,
    "adaptabilidade": 0.15,
    "equipamentos": 0.10,
}

def calcular_score(piloto: dict, anos: float, horas_totais: float, num_incidentes: int, num_certs: int) -> dict:
    comp = piloto.get("competencias", {})
    base_score = sum(comp.get(k, 70) * v for k, v in WEIGHTS.items())
    exp_bonus = min(anos * 0.8, 12)
    horas_bonus = min(horas_totais / 500, 8)
    incidente_penalty = num_incidentes * 3
    cert_bonus = num_certs * 1.5
    score_total = min(100, round(base_score + exp_bonus + horas_bonus - incidente_penalty + cert_bonus - 10))

    if score_total >= 90: nivel = "Elite"
    elif score_total >= 80: nivel = "Sênior"
    elif score_total >= 65: nivel = "Pleno"
    else: nivel = "Júnior"

    return {"score": score_total, "nivel": nivel}

def enrich_piloto(cur, row):
    pid = row["id"]
    p = dict(row)

    # Anos de experiência
    admissao = datetime.strptime(p["data_admissao"], "%Y-%m-%d")
    anos = (datetime.now() - admissao).days / 365.25
    p["anos_experiencia"] = round(anos, 1)

    # Certificações
    certs = cur.execute("SELECT tipo, numero, validade, emissora FROM certificacoes WHERE piloto_id=?", (pid,)).fetchall()
    p["certificacoes"] = [dict(c) for c in certs]

    # Aeronaves
    aero = cur.execute("SELECT modelo, data_habilitacao FROM aeronaves_habilitadas WHERE piloto_id=?", (pid,)).fetchall()
    p["aeronaves"] = [dict(a) for a in aero]

    # Especialidades
    esp = cur.execute("SELECT descricao FROM especialidades WHERE piloto_id=?", (pid,)).fetchall()
    p["especialidades"] = [e["descricao"] for e in esp]

    # Competências
    comp = cur.execute("SELECT * FROM competencias WHERE piloto_id=?", (pid,)).fetchone()
    p["competencias"] = dict(comp) if comp else {}

    # Horas de voo
    horas_row = cur.execute("SELECT COALESCE(SUM(duracao_min),0) as total FROM registros_voo WHERE piloto_id=?", (pid,)).fetchone()
    horas_totais = horas_row["total"] / 60
    p["horas_voo"] = round(horas_totais, 1)

    # Voos noturnos
    noturno = cur.execute("SELECT COUNT(*) as n FROM registros_voo WHERE piloto_id=? AND voo_noturno=1", (pid,)).fetchone()
    p["voos_noturnos"] = noturno["n"]

    # Incidentes
    inc = cur.execute("SELECT COUNT(*) as n FROM incidentes WHERE piloto_id=?", (pid,)).fetchone()
    p["num_incidentes"] = inc["n"]

    # Score
    score_data = calcular_score(p, anos, horas_totais, p["num_incidentes"], len(p["certificacoes"]))
    p["score"] = score_data["score"]
    p["nivel"] = score_data["nivel"]

    return p

@router.get("/ranking")
def get_ranking(db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    rows = cur.execute("SELECT * FROM pilotos WHERE status='ativo' ORDER BY nome").fetchall()
    pilotos = [enrich_piloto(cur, r) for r in rows]
    pilotos.sort(key=lambda x: x["score"], reverse=True)
    return {"total": len(pilotos), "pilotos": pilotos}

@router.get("/{piloto_id}")
def get_piloto(piloto_id: int, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    row = cur.execute("SELECT * FROM pilotos WHERE id=?", (piloto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Piloto não encontrado")
    p = enrich_piloto(cur, row)

    # Histórico de voos (últimos 20)
    voos = cur.execute("""SELECT data_voo, duracao_min, aeronave, tipo_operacao, voo_noturno, condicao_meteo
                          FROM registros_voo WHERE piloto_id=? ORDER BY data_voo DESC LIMIT 20""", (piloto_id,)).fetchall()
    p["historico_voos"] = [dict(v) for v in voos]

    # Incidentes detalhados
    incs = cur.execute("""SELECT data_incidente, tipo, severidade, descricao, acao_corretiva, encerrado
                          FROM incidentes WHERE piloto_id=? ORDER BY data_incidente DESC""", (piloto_id,)).fetchall()
    p["incidentes_detalhes"] = [dict(i) for i in incs]

    return p

@router.get("/")
def list_pilotos(db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    rows = cur.execute("SELECT * FROM pilotos ORDER BY nome").fetchall()
    return [dict(r) for r in rows]

class PilotoCreate(BaseModel):
    nome: str
    matricula: str
    base: str
    empresa: Optional[str] = "ALTAVE"
    data_admissao: str
    contato_email: Optional[str] = None
    lat_base: Optional[float] = None
    lon_base: Optional[float] = None
    observacoes: Optional[str] = None

@router.post("/", status_code=201)
def create_piloto(p: PilotoCreate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    try:
        cur.execute("""INSERT INTO pilotos (nome, matricula, base, empresa, data_admissao, contato_email, observacoes, lat_base, lon_base)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (p.nome, p.matricula, p.base, p.empresa, p.data_admissao, p.contato_email, p.observacoes, getattr(p,"lat_base",None), getattr(p,"lon_base",None)))
        pid = cur.lastrowid
        cur.execute("INSERT INTO competencias (piloto_id) VALUES (?)", (pid,))
        db.commit()
        return {"id": pid, "mensagem": "Piloto criado com sucesso"}
    except sqlite3.IntegrityError:
        raise HTTPException(400, "Matrícula já cadastrada")

class CompetenciaUpdate(BaseModel):
    tecnica_voo: int
    seguranca: int
    regulatorio: int
    trabalho_equipe: int
    adaptabilidade: int
    equipamentos: int
    avaliado_por: Optional[str] = None

@router.put("/{piloto_id}/competencias")
def update_competencias(piloto_id: int, c: CompetenciaUpdate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    row = cur.execute("SELECT id FROM pilotos WHERE id=?", (piloto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Piloto não encontrado")
    cur.execute("""UPDATE competencias SET
        tecnica_voo=?, seguranca=?, regulatorio=?, trabalho_equipe=?,
        adaptabilidade=?, equipamentos=?, avaliado_em=datetime('now'), avaliado_por=?
        WHERE piloto_id=?""",
        (c.tecnica_voo, c.seguranca, c.regulatorio, c.trabalho_equipe,
         c.adaptabilidade, c.equipamentos, c.avaliado_por, piloto_id))
    if cur.rowcount == 0:
        cur.execute("INSERT INTO competencias (piloto_id, tecnica_voo, seguranca, regulatorio, trabalho_equipe, adaptabilidade, equipamentos) VALUES (?,?,?,?,?,?,?,?,?)",
                    (piloto_id, c.tecnica_voo, c.seguranca, c.regulatorio, c.trabalho_equipe, c.adaptabilidade, c.equipamentos))
    db.commit()
    return {"mensagem": "Competências atualizadas"}

class CertCreate(BaseModel):
    tipo: str
    numero: Optional[str] = None
    validade: Optional[str] = None
    emissora: Optional[str] = None

@router.post("/{piloto_id}/certificacoes", status_code=201)
def add_cert(piloto_id: int, c: CertCreate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    cur.execute("INSERT INTO certificacoes (piloto_id, tipo, numero, validade, emissora) VALUES (?,?,?,?,?)",
                (piloto_id, c.tipo, c.numero, c.validade, c.emissora))
    db.commit()
    return {"id": cur.lastrowid}

class AeronaveCreate(BaseModel):
    modelo: str
    data_habilitacao: Optional[str] = None

@router.post("/{piloto_id}/aeronaves", status_code=201)
def add_aeronave(piloto_id: int, a: AeronaveCreate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    cur.execute("INSERT INTO aeronaves_habilitadas (piloto_id, modelo, data_habilitacao) VALUES (?,?,?)",
                (piloto_id, a.modelo, a.data_habilitacao))
    db.commit()
    return {"id": cur.lastrowid}

# Patch: adicionar ultima_missao ao enrich_piloto
_original_enrich = enrich_piloto
def enrich_piloto(cur, row):
    p = _original_enrich(cur, row)
    pid = p["id"]
    ultima = cur.execute("""SELECT data_voo, aeronave, tipo_operacao, lat_missao, lon_missao
                            FROM registros_voo WHERE piloto_id=? AND lat_missao IS NOT NULL
                            ORDER BY data_voo DESC LIMIT 1""", (pid,)).fetchone()
    p["ultima_missao"] = dict(ultima) if ultima else None
    return p

# ── FOTO UPLOAD ──
class FotoUpload(BaseModel):
    foto_base64: str  # data:image/jpeg;base64,...

@router.put("/{piloto_id}/foto")
def upload_foto(piloto_id: int, f: FotoUpload, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    row = cur.execute("SELECT id FROM pilotos WHERE id=?", (piloto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Piloto não encontrado")
    # Limite ~2MB em base64
    if len(f.foto_base64) > 2_800_000:
        raise HTTPException(400, "Imagem muito grande (máx 2MB)")
    cur.execute("UPDATE pilotos SET foto_base64=?, atualizado_em=datetime('now') WHERE id=?",
                (f.foto_base64, piloto_id))
    db.commit()
    return {"mensagem": "Foto atualizada"}

@router.delete("/{piloto_id}/foto")
def delete_foto(piloto_id: int, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    cur.execute("UPDATE pilotos SET foto_base64=NULL WHERE id=?", (piloto_id,))
    db.commit()
    return {"mensagem": "Foto removida"}

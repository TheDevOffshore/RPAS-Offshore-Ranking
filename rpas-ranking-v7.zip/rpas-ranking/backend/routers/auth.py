from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
import sqlite3
import hashlib
from database import get_db

router = APIRouter()

class LoginData(BaseModel):
    username: str
    senha: str

@router.post("/login")
def login(data: LoginData, db: sqlite3.Connection = Depends(get_db)):
    h = hashlib.sha256(data.senha.encode()).hexdigest()
    cur = db.cursor()
    row = cur.execute("SELECT id, username, role FROM usuarios WHERE username=? AND senha_hash=?",
                      (data.username, h)).fetchone()
    if not row:
        raise HTTPException(401, "Credenciais inválidas")
    return {"id": row["id"], "username": row["username"], "role": row["role"], "token": f"demo-{row['id']}"}

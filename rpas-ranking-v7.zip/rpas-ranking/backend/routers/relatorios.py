from fastapi import APIRouter, Depends
import sqlite3
from database import get_db

router = APIRouter()

@router.get("/resumo")
def resumo_geral(db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    total_pilotos = cur.execute("SELECT COUNT(*) FROM pilotos WHERE status='ativo'").fetchone()[0]
    total_voos = cur.execute("SELECT COUNT(*) FROM registros_voo").fetchone()[0]
    total_horas = cur.execute("SELECT COALESCE(SUM(duracao_min),0) FROM registros_voo").fetchone()[0] / 60
    total_incidentes = cur.execute("SELECT COUNT(*) FROM incidentes").fetchone()[0]
    total_certs = cur.execute("SELECT COUNT(*) FROM certificacoes").fetchone()[0]

    dist_nivel = cur.execute("""
        SELECT p.id, p.data_admissao,
               COALESCE(SUM(rv.duracao_min),0) as horas_min,
               COUNT(DISTINCT i.id) as inc,
               COUNT(DISTINCT c.id) as certs
        FROM pilotos p
        LEFT JOIN registros_voo rv ON rv.piloto_id = p.id
        LEFT JOIN incidentes i ON i.piloto_id = p.id
        LEFT JOIN certificacoes c ON c.piloto_id = p.id
        WHERE p.status='ativo'
        GROUP BY p.id
    """).fetchall()

    niveis = {"Elite": 0, "Sênior": 0, "Pleno": 0, "Júnior": 0}
    from datetime import datetime
    WEIGHTS = {"tecnica_voo":0.25,"seguranca":0.25,"regulatorio":0.15,"trabalho_equipe":0.10,"adaptabilidade":0.15,"equipamentos":0.10}
    for row in dist_nivel:
        comp = cur.execute("SELECT * FROM competencias WHERE piloto_id=?", (row["id"],)).fetchone()
        if not comp:
            niveis["Júnior"] += 1
            continue
        base = sum(comp[k] * v for k, v in WEIGHTS.items())
        admissao = datetime.strptime(row["data_admissao"], "%Y-%m-%d")
        anos = (datetime.now() - admissao).days / 365.25
        horas = row["horas_min"] / 60
        score = min(100, round(base + min(anos*0.8,12) + min(horas/500,8) - row["inc"]*3 + row["certs"]*1.5 - 10))
        if score >= 90: niveis["Elite"] += 1
        elif score >= 80: niveis["Sênior"] += 1
        elif score >= 65: niveis["Pleno"] += 1
        else: niveis["Júnior"] += 1

    bases = cur.execute("SELECT base, COUNT(*) as n FROM pilotos WHERE status='ativo' GROUP BY base").fetchall()

    return {
        "total_pilotos": total_pilotos,
        "total_voos_registrados": total_voos,
        "total_horas_frota": round(total_horas, 1),
        "total_incidentes": total_incidentes,
        "total_certificacoes": total_certs,
        "distribuicao_nivel": niveis,
        "pilotos_por_base": [dict(b) for b in bases],
    }

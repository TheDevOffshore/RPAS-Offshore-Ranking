from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import sqlite3
from database import get_db

router = APIRouter()

class IncidenteCreate(BaseModel):
    piloto_id: int
    data_incidente: str
    tipo: str
    severidade: Optional[str] = "baixa"
    descricao: Optional[str] = None
    acao_corretiva: Optional[str] = None

@router.post("/", status_code=201)
def registrar_incidente(i: IncidenteCreate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    row = cur.execute("SELECT id FROM pilotos WHERE id=?", (i.piloto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Piloto não encontrado")
    cur.execute("""INSERT INTO incidentes
        (piloto_id, data_incidente, tipo, severidade, descricao, acao_corretiva)
        VALUES (?,?,?,?,?,?)""",
        (i.piloto_id, i.data_incidente, i.tipo, i.severidade, i.descricao, i.acao_corretiva))
    db.commit()
    return {"id": cur.lastrowid, "mensagem": "Incidente registrado"}

@router.get("/piloto/{piloto_id}")
def get_incidentes_piloto(piloto_id: int, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    rows = cur.execute("""SELECT * FROM incidentes WHERE piloto_id=? ORDER BY data_incidente DESC""",
                       (piloto_id,)).fetchall()
    return [dict(r) for r in rows]

@router.put("/{incidente_id}/encerrar")
def encerrar_incidente(incidente_id: int, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    cur.execute("UPDATE incidentes SET encerrado=1 WHERE id=?", (incidente_id,))
    db.commit()
    return {"mensagem": "Incidente encerrado"}

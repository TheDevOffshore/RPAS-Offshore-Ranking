from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import sqlite3
from database import get_db

router = APIRouter()

class VooCreate(BaseModel):
    piloto_id: int
    data_voo: str
    duracao_min: int
    aeronave: str
    base: Optional[str] = None
    tipo_operacao: Optional[str] = None
    condicao_meteo: Optional[str] = "bom"
    voo_noturno: Optional[bool] = False
    voo_sobre_agua: Optional[bool] = True
    observacoes: Optional[str] = None
    lat_missao: Optional[float] = None
    lon_missao: Optional[float] = None

@router.post("/", status_code=201)
def registrar_voo(v: VooCreate, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    row = cur.execute("SELECT id FROM pilotos WHERE id=?", (v.piloto_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Piloto não encontrado")
    cur.execute("""INSERT INTO registros_voo
        (piloto_id, data_voo, duracao_min, aeronave, base, tipo_operacao, condicao_meteo,
         voo_noturno, voo_sobre_agua, observacoes, lat_missao, lon_missao)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (v.piloto_id, v.data_voo, v.duracao_min, v.aeronave, v.base,
         v.tipo_operacao, v.condicao_meteo, int(v.voo_noturno), int(v.voo_sobre_agua),
         v.observacoes, v.lat_missao, v.lon_missao))
    db.commit()
    return {"id": cur.lastrowid, "mensagem": "Voo registrado"}

@router.get("/piloto/{piloto_id}")
def get_voos_piloto(piloto_id: int, limit: int = 50, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    rows = cur.execute("SELECT * FROM registros_voo WHERE piloto_id=? ORDER BY data_voo DESC LIMIT ?",
                       (piloto_id, limit)).fetchall()
    return [dict(r) for r in rows]

@router.get("/stats/{piloto_id}")
def get_stats_voo(piloto_id: int, db: sqlite3.Connection = Depends(get_db)):
    cur = db.cursor()
    stats = cur.execute("""
        SELECT COUNT(*) as total_voos,
               COALESCE(SUM(duracao_min),0) as total_minutos,
               COALESCE(SUM(CASE WHEN voo_noturno=1 THEN 1 ELSE 0 END),0) as voos_noturnos,
               COALESCE(SUM(CASE WHEN voo_sobre_agua=1 THEN 1 ELSE 0 END),0) as voos_agua,
               COUNT(DISTINCT aeronave) as aeronaves_distintas
        FROM registros_voo WHERE piloto_id=?
    """, (piloto_id,)).fetchone()
    d = dict(stats)
    d["horas_totais"] = round(d["total_minutos"] / 60, 1)
    return d

import sqlite3
import os
import hashlib
import random
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "rpas_ranking.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        senha_hash TEXT NOT NULL,
        role TEXT DEFAULT 'operador',
        criado_em TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS pilotos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        matricula TEXT UNIQUE NOT NULL,
        base TEXT NOT NULL,
        empresa TEXT DEFAULT 'ALTAVE',
        data_admissao TEXT NOT NULL,
        status TEXT DEFAULT 'ativo',
        foto_url TEXT,
        foto_base64 TEXT,
        contato_email TEXT,
        observacoes TEXT,
        lat_base REAL,
        lon_base REAL,
        criado_em TEXT DEFAULT (datetime('now')),
        atualizado_em TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS certificacoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER NOT NULL,
        tipo TEXT NOT NULL,
        numero TEXT,
        validade TEXT,
        emissora TEXT,
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS aeronaves_habilitadas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER NOT NULL,
        modelo TEXT NOT NULL,
        data_habilitacao TEXT,
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS competencias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER UNIQUE NOT NULL,
        tecnica_voo INTEGER DEFAULT 70,
        seguranca INTEGER DEFAULT 70,
        regulatorio INTEGER DEFAULT 70,
        trabalho_equipe INTEGER DEFAULT 70,
        adaptabilidade INTEGER DEFAULT 70,
        equipamentos INTEGER DEFAULT 70,
        avaliado_em TEXT DEFAULT (datetime('now')),
        avaliado_por TEXT,
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS registros_voo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER NOT NULL,
        data_voo TEXT NOT NULL,
        duracao_min INTEGER NOT NULL,
        aeronave TEXT NOT NULL,
        base TEXT,
        tipo_operacao TEXT,
        condicao_meteo TEXT DEFAULT 'bom',
        voo_noturno INTEGER DEFAULT 0,
        voo_sobre_agua INTEGER DEFAULT 0,
        lat_missao REAL,
        lon_missao REAL,
        observacoes TEXT,
        registrado_em TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS incidentes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER NOT NULL,
        data_incidente TEXT NOT NULL,
        tipo TEXT NOT NULL,
        severidade TEXT DEFAULT 'baixa',
        descricao TEXT,
        acao_corretiva TEXT,
        encerrado INTEGER DEFAULT 0,
        registrado_em TEXT DEFAULT (datetime('now')),
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS especialidades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        piloto_id INTEGER NOT NULL,
        descricao TEXT NOT NULL,
        FOREIGN KEY (piloto_id) REFERENCES pilotos(id) ON DELETE CASCADE
    );
    """)

    _seed_data(cur)
    conn.commit()
    conn.close()
    print("✅ Banco inicializado com sucesso")

def _seed_data(cur):
    cur.execute("SELECT COUNT(*) FROM pilotos")
    if cur.fetchone()[0] > 0:
        return

    def h(pwd): return hashlib.sha256(pwd.encode()).hexdigest()
    cur.execute("INSERT INTO usuarios (username, senha_hash, role) VALUES (?,?,?)",
                ("admin", h("admin123"), "admin"))
    cur.execute("INSERT INTO usuarios (username, senha_hash, role) VALUES (?,?,?)",
                ("operador", h("op123"), "operador"))

    pilotos = [
        ("William Oliveira",      "P-001", "Santos Basin",  "2010-06-01", -23.9, -43.2),
        ("Carlos Henrique Faria", "P-002", "Campos Basin",  "2015-03-10", -22.8, -41.0),
        ("Renata Alves Costa",    "P-003", "Campos Basin",  "2018-08-15", -22.8, -41.0),
        ("Eduardo Menezes",       "P-004", "Pre-sal FPSO",  "2016-01-20", -23.5, -42.5),
        ("Fernanda Reis",         "P-005", "Santos Basin",  "2020-04-05", -23.9, -43.2),
        ("Rodrigo Santana",       "P-006", "Campos Basin",  "2021-09-12", -22.8, -41.0),
        ("Marcelo Torres",        "P-007", "Pre-sal FPSO",  "2022-11-30", -23.5, -42.5),
    ]

    competencias_data = [
        (99, 99, 99, 98, 99, 99),
        (95, 98, 92, 88, 90, 96),
        (89, 91, 94, 95, 87, 88),
        (90, 85, 88, 82, 92, 94),
        (82, 94, 90, 93, 85, 80),
        (72, 80, 78, 85, 75, 70),
        (65, 85, 72, 78, 70, 62),
    ]

    certs_data = [
        ["ANAC", "DECEA", "NR-34", "FAR 107", "EASA"],
        ["ANAC", "DECEA", "NR-34"],
        ["ANAC", "DECEA", "NR-34", "FAR 107"],
        ["ANAC", "DECEA", "NR-34", "EASA"],
        ["ANAC", "DECEA", "NR-34"],
        ["ANAC", "DECEA"],
        ["ANAC", "DECEA"],
    ]

    aeronaves_data = [
        ["M300 RTK", "M350 RTK", "M30T", "Mavic 3E"],
        ["M300 RTK", "M350 RTK", "M30T"],
        ["M300 RTK", "M30T"],
        ["M300 RTK", "M350 RTK", "M30T", "Mavic 3E"],
        ["M300 RTK", "M30T"],
        ["M300 RTK"],
        ["M30T"],
    ]

    esp_data = [
        ["Ops offshore P&G", "SARPAS", "Fotogrametria", "RTK avançado", "YOLOv8", "IA embarcada"],
        ["Inspeção estrutural", "VOO noturno", "RTK avançado"],
        ["VOO noturno", "Inspeção de flare", "DP vessel"],
        ["FPSO", "Operação em mar agitado", "VOO multi-aeronave"],
        ["Análise de dados", "YOLOv8", "Relatórios técnicos"],
        ["Pre-flight check", "Logística"],
        ["Mapeamento", "GNSS"],
    ]

    # Horas alvo reais
    horas_alvo  = [8500, 4200, 2750, 3900, 1600,  900,  520]
    incidentes_c = [   0,    0,    1,    1,    0,    1,    0]

    missao_coords = [
        (-23.7, -43.8),
        (-22.4, -40.5),
        (-22.9, -41.2),
        (-24.1, -44.0),
        (-23.2, -42.8),
        (-22.6, -40.8),
        (-23.8, -43.5),
    ]

    for i, (nome, mat, base, admissao, lat, lon) in enumerate(pilotos):
        cur.execute("""INSERT INTO pilotos (nome, matricula, base, data_admissao, lat_base, lon_base)
                       VALUES (?,?,?,?,?,?)""", (nome, mat, base, admissao, lat, lon))
        pid = cur.lastrowid

        for c in certs_data[i]:
            cur.execute("INSERT INTO certificacoes (piloto_id, tipo) VALUES (?,?)", (pid, c))
        for a in aeronaves_data[i]:
            cur.execute("INSERT INTO aeronaves_habilitadas (piloto_id, modelo) VALUES (?,?)", (pid, a))
        for e in esp_data[i]:
            cur.execute("INSERT INTO especialidades (piloto_id, descricao) VALUES (?,?)", (pid, e))

        comp = competencias_data[i]
        cur.execute("""INSERT INTO competencias
            (piloto_id, tecnica_voo, seguranca, regulatorio, trabalho_equipe, adaptabilidade, equipamentos)
            VALUES (?,?,?,?,?,?,?)""", (pid, *comp))

        # Gerar voos com durações variadas para atingir horas reais
        horas = horas_alvo[i]
        minutos_restantes = horas * 60
        aeros = aeronaves_data[i]
        mlat, mlon = missao_coords[i]
        j = 0
        voos = []
        while minutos_restantes > 0:
            dur = random.choice([60, 75, 90, 120, 150])
            dur = min(dur, minutos_restantes)
            dias_atras = random.randint(1, 3650)
            data = (datetime.now() - timedelta(days=dias_atras)).strftime("%Y-%m-%d")
            aeronave = aeros[j % len(aeros)]
            noturno = 1 if j % 8 == 0 else 0
            lm = mlat if minutos_restantes <= dur else None
            lo = mlon if minutos_restantes <= dur else None
            voos.append((pid, data, dur, aeronave, base, "inspeção", noturno, 1, lm, lo))
            minutos_restantes -= dur
            j += 1

        cur.executemany("""INSERT INTO registros_voo
            (piloto_id, data_voo, duracao_min, aeronave, base, tipo_operacao,
             voo_noturno, voo_sobre_agua, lat_missao, lon_missao)
            VALUES (?,?,?,?,?,?,?,?,?,?)""", voos)

        for k in range(incidentes_c[i]):
            cur.execute("""INSERT INTO incidentes
                (piloto_id, data_incidente, tipo, severidade, descricao, encerrado)
                VALUES (?,?,?,?,?,?)""",
                (pid, "2023-06-15", "operacional", "baixa",
                 "Registro de ocorrência operacional", 1))

#!/bin/bash
# ============================================================
#  RPAS Offshore Ranking — Script de inicialização
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ██████╗ ██████╗  █████╗ ███████╗"
echo "  ██╔══██╗██╔══██╗██╔══██╗██╔════╝"
echo "  ██████╔╝██████╔╝███████║███████╗"
echo "  ██╔══██╗██╔═══╝ ██╔══██║╚════██║"
echo "  ██║  ██║██║     ██║  ██║███████║"
echo "  ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚══════╝"
echo "  RPAS Offshore Ranking — v1.0.0"
echo ""

# Instalar dependências
echo "📦 Instalando dependências Python..."
pip install -r "$SCRIPT_DIR/requirements.txt" -q --break-system-packages

# Iniciar backend
echo "🚀 Iniciando backend FastAPI na porta 8000..."
cd "$SCRIPT_DIR/backend"
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!

sleep 2

echo ""
echo "✅ Sistema iniciado!"
echo ""
echo "  📡 API:       http://localhost:8000"
echo "  📖 Docs:      http://localhost:8000/docs"
echo "  🌐 Frontend:  Abra o arquivo frontend/index.html no navegador"
echo "               (ou use: python -m http.server 3000 na pasta frontend)"
echo ""
echo "  👤 Login admin:    admin / admin123"
echo "  👤 Login operador: operador / op123"
echo ""
echo "  Pressione Ctrl+C para encerrar."
echo ""

wait $BACKEND_PID

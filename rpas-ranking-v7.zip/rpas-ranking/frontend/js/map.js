// ================================================================
//  TACTICAL OPERATIONS MAP — Glowing pulse markers
// ================================================================

let tacMap = null;
let mapMarkers = [];

function initMap() {
  tacMap = L.map('tacMap', {
    center: [-23.5, -42.0],
    zoom: 6,
    zoomControl: true,
    attributionControl: false,
  });

  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 18,
  }).addTo(tacMap);

  // Injetar CSS de animação no documento
  if (!document.getElementById('map-pulse-css')) {
    const style = document.createElement('style');
    style.id = 'map-pulse-css';
    style.textContent = `
      /* Leaflet popup dark override */
      .leaflet-popup-content-wrapper {
        background: #0D1210 !important;
        border: 1px solid #2F4232 !important;
        border-radius: 0 !important;
        box-shadow: 0 0 20px rgba(74,255,145,.15) !important;
        padding: 0 !important;
      }
      .leaflet-popup-tip { background: #0D1210 !important; }
      .leaflet-popup-content { margin: 0 !important; }

      /* Pulse rings para base */
      @keyframes ping-base {
        0%   { transform: scale(1);   opacity: .7; }
        70%  { transform: scale(2.8); opacity: 0; }
        100% { transform: scale(1);   opacity: 0; }
      }
      @keyframes ping-mission {
        0%   { transform: scale(1);   opacity: .6; }
        70%  { transform: scale(2.4); opacity: 0; }
        100% { transform: scale(1);   opacity: 0; }
      }
      .pulse-ring-base    { animation: ping-base    2.2s ease-out infinite; }
      .pulse-ring-mission { animation: ping-mission 2.8s ease-out infinite; }

      /* Cores por rank */
      .dot-rank-1 { background: #FFB700; box-shadow: 0 0 10px #FFB700, 0 0 20px #FFB70088; }
      .dot-rank-2 { background: #C8C8C0; box-shadow: 0 0 8px #C8C8C088; }
      .dot-rank-3 { background: #CD7F32; box-shadow: 0 0 8px #CD7F3288; }
      .dot-rank-n { background: #4AFF91; box-shadow: 0 0 6px #4AFF9166; }
      .dot-mission{ background: #FFB700; box-shadow: 0 0 8px #FFB70088; }

      .ring-rank-1 { border-color: #FFB700; }
      .ring-rank-2 { border-color: #C8C8C0; }
      .ring-rank-3 { border-color: #CD7F32; }
      .ring-rank-n { border-color: #4AFF91; }
    `;
    document.head.appendChild(style);
  }
}

function getRankClass(rank) {
  if (rank === 1) return 'rank-1';
  if (rank === 2) return 'rank-2';
  if (rank === 3) return 'rank-3';
  return 'rank-n';
}

function getDotSize(rank) {
  if (rank === 1) return 16;
  if (rank <= 3) return 13;
  return 10;
}

// Cria ícone de bola brilhante pulsante para a BASE do piloto
function createGlowBaseIcon(rank) {
  const rc = getRankClass(rank);
  const size = getDotSize(rank);
  const total = size * 4;
  const center = total / 2;
  const delay = rank * 0.3;

  const html = `
    <div style="position:relative;width:${total}px;height:${total}px;display:flex;align-items:center;justify-content:center">
      <!-- Anel pulsante externo -->
      <div class="pulse-ring-base ring-${rc}"
           style="position:absolute;width:${size*2}px;height:${size*2}px;
                  border-radius:50%;border:1.5px solid;
                  animation-delay:${delay}s"></div>
      <!-- Anel pulsante interno -->
      <div class="pulse-ring-base ring-${rc}"
           style="position:absolute;width:${size*1.4}px;height:${size*1.4}px;
                  border-radius:50%;border:1px solid;opacity:.5;
                  animation-delay:${delay + 0.4}s"></div>
      <!-- Bola central -->
      <div class="dot-${rc}"
           style="width:${size}px;height:${size}px;border-radius:50%;
                  position:relative;z-index:2;border:1.5px solid rgba(255,255,255,.2)">
      </div>
    </div>`;

  return L.divIcon({
    html,
    className: '',
    iconSize: [total, total],
    iconAnchor: [center, center],
    popupAnchor: [0, -center],
  });
}

// Ícone losango âmbar para última missão
function createMissionIcon() {
  const html = `
    <div style="position:relative;width:40px;height:40px;display:flex;align-items:center;justify-content:center">
      <div class="pulse-ring-mission"
           style="position:absolute;width:24px;height:24px;
                  border:1.5px solid #FFB700;border-radius:2px;transform:rotate(45deg);
                  animation-delay:.6s"></div>
      <div style="width:10px;height:10px;background:#FFB700;
                  transform:rotate(45deg);position:relative;z-index:2;
                  box-shadow:0 0 8px #FFB700,0 0 16px #FFB70066"></div>
    </div>`;
  return L.divIcon({
    html,
    className: '',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
    popupAnchor: [0, -20],
  });
}

function buildPopupHtml(p, rank) {
  const scoreColor = p.score >= 90 ? '#FFB700' : p.score >= 80 ? '#4AFF91' : p.score >= 65 ? '#5BC0F8' : '#7A9B7E';
  return `
    <div style="font-family:'Share Tech Mono',monospace;background:#0D1210;
                padding:12px 16px;min-width:210px;color:#E8EFE9">
      <div style="font-size:9px;letter-spacing:.12em;color:#3D5C42;text-transform:uppercase;margin-bottom:5px">
        BASE · ${p.nivel?.toUpperCase()}
      </div>
      <div style="font-size:14px;color:#E8EFE9;text-transform:uppercase;letter-spacing:.05em;font-weight:400">
        ${p.nome}
      </div>
      <div style="font-size:10px;color:#7A9B7E;margin-top:3px;letter-spacing:.04em">
        ${p.base?.toUpperCase()}
      </div>
      <div style="display:flex;justify-content:space-between;
                  margin-top:10px;border-top:1px solid #1E2B1F;padding-top:8px;gap:8px">
        <div style="text-align:center">
          <div style="font-size:20px;color:${scoreColor}">${p.score}</div>
          <div style="font-size:9px;color:#3D5C42;letter-spacing:.08em;text-transform:uppercase">Score</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:20px;color:#5BC0F8">${Math.round(p.horas_voo)}</div>
          <div style="font-size:9px;color:#3D5C42;letter-spacing:.08em;text-transform:uppercase">H.Voo</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:20px;color:${p.num_incidentes===0?'#4AFF91':'#FF3B3B'}">${p.num_incidentes}</div>
          <div style="font-size:9px;color:#3D5C42;letter-spacing:.08em;text-transform:uppercase">INC</div>
        </div>
      </div>
      <a href="piloto.html?id=${p.id}"
         style="display:block;margin-top:8px;font-size:10px;color:#4AFF91;
                text-decoration:none;letter-spacing:.08em;text-transform:uppercase;
                text-align:center;border:1px solid #1A4A2E;padding:5px">
        VER PERFIL COMPLETO ›
      </a>
    </div>`;
}

function buildMissionPopup(p) {
  return `
    <div style="font-family:'Share Tech Mono',monospace;background:#0D1210;
                padding:10px 14px;min-width:190px;color:#E8EFE9">
      <div style="font-size:9px;letter-spacing:.12em;color:#3D5C42;text-transform:uppercase;margin-bottom:5px">
        ÚLTIMA MISSÃO
      </div>
      <div style="font-size:13px;color:#FFB700;text-transform:uppercase;letter-spacing:.04em">
        ${p.nome}
      </div>
      <div style="font-size:10px;color:#7A9B7E;margin-top:4px">${p.ultima_missao?.aeronave || '—'}</div>
      <div style="font-size:10px;color:#3D5C42;margin-top:2px">${p.ultima_missao?.data_voo || '—'}</div>
      <div style="font-size:9px;color:#3D5C42;margin-top:4px;letter-spacing:.05em">
        ${p.ultima_missao?.lat_missao?.toFixed(4)}, ${p.ultima_missao?.lon_missao?.toFixed(4)}
      </div>
    </div>`;
}

function updateMap(pilotos) {
  if (!tacMap) return;

  // Limpar marcadores anteriores
  mapMarkers.forEach(m => tacMap.removeLayer(m));
  mapMarkers = [];

  const bounds = [];

  pilotos.forEach((p, i) => {
    const rank = i + 1;

    // ── MARCADOR DA BASE ──
    if (p.lat_base && p.lon_base) {
      const icon = createGlowBaseIcon(rank);
      const marker = L.marker([p.lat_base, p.lon_base], { icon, zIndexOffset: 1000 - rank })
        .bindPopup(buildPopupHtml(p, rank), { className: '', maxWidth: 240 })
        .addTo(tacMap);
      mapMarkers.push(marker);
      bounds.push([p.lat_base, p.lon_base]);
    }

    // ── MARCADOR DE ÚLTIMA MISSÃO ──
    if (p.ultima_missao?.lat_missao && p.ultima_missao?.lon_missao) {
      const mLat = p.ultima_missao.lat_missao;
      const mLon = p.ultima_missao.lon_missao;

      const mMarker = L.marker([mLat, mLon], { icon: createMissionIcon(), zIndexOffset: 500 - rank })
        .bindPopup(buildMissionPopup(p), { className: '', maxWidth: 220 })
        .addTo(tacMap);
      mapMarkers.push(mMarker);

      // Linha tracejada base → missão
      if (p.lat_base && p.lon_base) {
        const line = L.polyline(
          [[p.lat_base, p.lon_base], [mLat, mLon]],
          { color: '#4AFF91', weight: 1, opacity: 0.2, dashArray: '5,8' }
        ).addTo(tacMap);
        mapMarkers.push(line);
      }
      bounds.push([mLat, mLon]);
    }
  });

  if (bounds.length > 0) {
    tacMap.fitBounds(bounds, { padding: [50, 50], maxZoom: 8 });
  }
}

/* ================================================================
   USAF-Inspired Rank Insignia — Pure SVG
   Mapping to RPAS Offshore levels:

   JÚNIOR  → Airman First Class (E-3): 2 chevrons, no star
   PLENO   → Senior Airman (E-4):      3 chevrons + center star
   SÊNIOR  → Staff Sergeant (E-5):     3 chevrons + star + rocker
   ELITE   → Chief Master Sergeant(E-9): 3 chevrons + star + 3 rockers + diamond

   Colors follow USAF dress blues palette adapted to tactical dark theme.
   ================================================================ */

const INSIGNIA = {

  Júnior: {
    label: 'AIRMAN · E-3',
    color: '#5A8AAA',
    cls: 'insig-junior',
    svg: (c) => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 72" width="80" height="72">
  <!-- Background shield -->
  <path d="M40 4 L72 14 L72 50 Q72 68 40 72 Q8 68 8 50 L8 14 Z"
        fill="none" stroke="${c}" stroke-width="1" opacity="0.25"/>

  <!-- Chevron 1 (bottom) -->
  <polyline points="16,54 40,38 64,54"
    fill="none" stroke="${c}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
  <!-- Chevron 2 (top) -->
  <polyline points="16,44 40,28 64,44"
    fill="none" stroke="${c}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>

  <!-- Center star small -->
  <polygon points="40,14 42,20 48,20 43,24 45,30 40,26 35,30 37,24 32,20 38,20"
    fill="${c}" opacity="0.6"/>
</svg>`
  },

  Pleno: {
    label: 'SENIOR AIRMAN · E-4',
    color: '#00D4FF',
    cls: 'insig-pleno',
    svg: (c) => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 76" width="80" height="76">
  <!-- Shield outline -->
  <path d="M40 3 L74 14 L74 52 Q74 70 40 76 Q6 70 6 52 L6 14 Z"
        fill="rgba(91,192,248,0.04)" stroke="${c}" stroke-width="1" opacity="0.35"/>

  <!-- 3 chevrons -->
  <polyline points="14,62 40,46 66,62"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,52 40,36 66,52"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,42 40,26 66,42"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>

  <!-- Center 5-point star -->
  <polygon points="40,6 43,15 52,15 45,21 48,30 40,24 32,30 35,21 28,15 37,15"
    fill="${c}" opacity="0.9"/>
</svg>`
  },

  Sênior: {
    label: 'STAFF SERGEANT · E-5',
    color: '#4A9EFF',
    cls: 'insig-senior',
    svg: (c) => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 82" width="80" height="82">
  <!-- Shield -->
  <path d="M40 3 L74 14 L74 55 Q74 74 40 82 Q6 74 6 55 L6 14 Z"
        fill="rgba(74,255,145,0.05)" stroke="${c}" stroke-width="1" opacity="0.4"/>

  <!-- Rocker arc bottom -->
  <path d="M14,75 Q40,85 66,75"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round"/>

  <!-- 3 chevrons -->
  <polyline points="14,65 40,50 66,65"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,55 40,40 66,55"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,45 40,30 66,45"
    fill="none" stroke="${c}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>

  <!-- Star -->
  <polygon points="40,6 43.5,16 54,16 46,22 49,32 40,26 31,32 34,22 26,16 36.5,16"
    fill="${c}" opacity="0.95"/>

  <!-- Wing lines on star -->
  <line x1="22" y1="16" x2="28" y2="16" stroke="${c}" stroke-width="1.5" opacity="0.5"/>
  <line x1="52" y1="16" x2="58" y2="16" stroke="${c}" stroke-width="1.5" opacity="0.5"/>
</svg>`
  },

  Elite: {
    label: 'CHIEF MASTER SGT · E-9',
    color: '#FFB700',
    cls: 'insig-elite',
    svg: (c) => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 88 96" width="88" height="96">
  <!-- Shield glow fill -->
  <path d="M44 3 L80 16 L80 60 Q80 80 44 96 Q8 80 8 60 L8 16 Z"
        fill="rgba(255,183,0,0.06)" stroke="${c}" stroke-width="1.5" opacity="0.5"/>
  <!-- Inner shield -->
  <path d="M44 10 L74 20 L74 58 Q74 74 44 86 Q14 74 14 58 L14 20 Z"
        fill="none" stroke="${c}" stroke-width="0.5" opacity="0.25"/>

  <!-- 3 rockers -->
  <path d="M14,88 Q44,98 74,88"
    fill="none" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M14,82 Q44,92 74,82"
    fill="none" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M14,76 Q44,86 74,76"
    fill="none" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/>

  <!-- 3 chevrons -->
  <polyline points="14,68 44,52 74,68"
    fill="none" stroke="${c}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,58 44,42 74,58"
    fill="none" stroke="${c}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="14,48 44,32 74,48"
    fill="none" stroke="${c}" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>

  <!-- Large star -->
  <polygon points="44,5 48.5,17 62,17 52,25 56,37 44,29 32,37 36,25 26,17 39.5,17"
    fill="${c}"/>

  <!-- Diamond center (Chief Master Sgt hallmark) -->
  <polygon points="44,19 47,23 44,27 41,23"
    fill="var(--bg-void)" stroke="${c}" stroke-width="1"/>

  <!-- Horizontal bars flanking star (service stripes) -->
  <line x1="10" y1="21" x2="22" y2="21" stroke="${c}" stroke-width="2" opacity="0.6"/>
  <line x1="10" y1="25" x2="22" y2="25" stroke="${c}" stroke-width="2" opacity="0.6"/>
  <line x1="66" y1="21" x2="78" y2="21" stroke="${c}" stroke-width="2" opacity="0.6"/>
  <line x1="66" y1="25" x2="78" y2="25" stroke="${c}" stroke-width="2" opacity="0.6"/>
</svg>`
  }
};

/**
 * Retorna o HTML completo da patente para um dado nível
 * @param {string} nivel - 'Júnior' | 'Pleno' | 'Sênior' | 'Elite'
 * @param {boolean} showLabel - mostrar label abaixo
 */
function getInsigniaHTML(nivel, showLabel = true) {
  const ins = INSIGNIA[nivel] || INSIGNIA['Júnior'];
  return `
    <div class="rank-insignia-wrap ${ins.cls}">
      ${ins.svg(ins.color)}
      ${showLabel ? `<div class="insig-label" style="color:${ins.color}">${ins.label}</div>` : ''}
    </div>`;
}

window.getInsigniaHTML = getInsigniaHTML;
window.INSIGNIA = INSIGNIA;

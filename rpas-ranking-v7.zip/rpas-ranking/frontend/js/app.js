const API = 'http://localhost:8000/api';

const COMP_COLORS = {
  tecnica_voo: '#4AFF91',
  seguranca: '#5BC0F8',
  regulatorio: '#C89FFF',
  trabalho_equipe: '#FFB700',
  adaptabilidade: '#FF8C00',
  equipamentos: '#4AFFD4'
};
const COMP_LABELS = {
  tecnica_voo: 'Técnica de voo',
  seguranca: 'Segurança',
  regulatorio: 'Regulatório',
  trabalho_equipe: 'Trab. equipe',
  adaptabilidade: 'Adaptabilidade',
  equipamentos: 'Equipamentos'
};

let allPilotos = [];
let currentFilter = 'todos';
let currentSort = 'score';
let currentSearch = '';

// UTC Clock
function updateClock() {
  const now = new Date();
  const h = String(now.getUTCHours()).padStart(2,'0');
  const m = String(now.getUTCMinutes()).padStart(2,'0');
  const s = String(now.getUTCSeconds()).padStart(2,'0');
  const el = document.getElementById('utcClock');
  if (el) el.textContent = `${h}:${m}:${s} UTC`;
}
setInterval(updateClock, 1000);
updateClock();

async function fetchRanking() {
  try {
    const res = await fetch(`${API}/pilotos/ranking`);
    const data = await res.json();
    allPilotos = data.pilotos;
    renderKPIs(data);
    renderRanking();
    populatePilotoSelect();
    initMap();
    updateMap(allPilotos);
    const badge = document.getElementById('userBadge');
    if (badge) badge.textContent = `${data.total} pilots · br-ofx online`;
  } catch (e) {
    document.getElementById('rankingList').innerHTML =
      `<div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i>Connection failed — backend offline<br><small style="font-size:10px;margin-top:4px;display:block">Verifique se o servidor está rodando em localhost:8000</small></div>`;
  }
}

function renderKPIs(data) {
  const totalHoras = allPilotos.reduce((s,p) => s + p.horas_voo, 0);
  const avgScore = Math.round(allPilotos.reduce((s,p) => s + p.score, 0) / allPilotos.length);
  const semIncidente = allPilotos.filter(p => p.num_incidentes === 0).length;
  const elite = allPilotos.filter(p => p.nivel === 'Elite').length;
  document.getElementById('kpiGrid').innerHTML = `
    <div class="kpi-card kpi-hi">
      <div class="kpi-label">Active Pilots</div>
      <div class="kpi-value">${data.total}</div>
      <div class="kpi-sub">br-offshore fleet</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Avg Score</div>
      <div class="kpi-value">${avgScore}</div>
      <div class="kpi-sub">/ 100 pts</div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Flight Hours</div>
      <div class="kpi-value">${Math.round(totalHoras).toLocaleString('pt-BR')}</div>
      <div class="kpi-sub">total fleet</div>
    </div>
    <div class="kpi-card ${semIncidente === data.total ? 'kpi-hi' : ''}">
      <div class="kpi-label">Zero Incidents</div>
      <div class="kpi-value">${semIncidente}</div>
      <div class="kpi-sub">of ${data.total} pilots</div>
    </div>
    <div class="kpi-card kpi-warn">
      <div class="kpi-label">Elite Level</div>
      <div class="kpi-value">${elite}</div>
      <div class="kpi-sub">operators qualified</div>
    </div>
  `;
}

function getFilteredSorted() {
  let list = [...allPilotos];
  if (currentFilter !== 'todos') list = list.filter(p => p.nivel === currentFilter);
  if (currentSearch) {
    const q = currentSearch.toLowerCase();
    list = list.filter(p => p.nome.toLowerCase().includes(q) || p.base.toLowerCase().includes(q));
  }
  if (currentSort === 'score') list.sort((a,b) => b.score - a.score);
  else if (currentSort === 'horas') list.sort((a,b) => b.horas_voo - a.horas_voo);
  else if (currentSort === 'anos') list.sort((a,b) => b.anos_experiencia - a.anos_experiencia);
  else if (currentSort === 'incidentes') list.sort((a,b) => a.num_incidentes - b.num_incidentes);
  return list;
}

function getScoreColor(score) {
  if (score >= 90) return '#FFB700';
  if (score >= 80) return '#4AFF91';
  if (score >= 65) return '#5BC0F8';
  return '#7A9B7E';
}

function initials(nome) {
  return nome.split(' ').slice(0,2).map(x=>x[0]).join('');
}

function renderRanking() {
  const list = getFilteredSorted();
  const container = document.getElementById('rankingList');
  if (!list.length) {
    container.innerHTML = '<div class="empty-state"><i class="fa-solid fa-magnifying-glass"></i>No pilots found — adjust filter</div>';
    return;
  }

  container.innerHTML = list.map((p, i) => {
    const globalRank = allPilotos.findIndex(x => x.id === p.id) + 1;
    const rankLabel = globalRank === 1 ? '◈ 01' : globalRank === 2 ? '◉ 02' : globalRank === 3 ? '◎ 03' : `#${String(globalRank).padStart(2,'0')}`;
    const rankCls = globalRank <= 3 ? `rank-${globalRank}` : '';
    const scoreColor = getScoreColor(p.score);

    const certsHtml = (p.certificacoes||[]).map(c => {
      const key = c.tipo.replace(/\s/g,'-');
      return `<span class="cert-tag cert-${key}">${c.tipo}</span>`;
    }).join('');

    const trendIcon = globalRank <= 2 ? '▲' : globalRank <= 4 ? '▶' : '▼';
    const trendCls = globalRank <= 2 ? 'trend-up' : globalRank <= 4 ? 'trend-st' : 'trend-dn';

    const compBars = Object.entries(COMP_LABELS).map(([k,label]) => {
      const val = p.competencias?.[k] ?? 70;
      return `<div class="comp-row">
        <span class="comp-label">${label}</span>
        <div class="comp-bar-bg"><div class="comp-bar-fill" style="width:${val}%;background:${COMP_COLORS[k]}"></div></div>
        <span class="comp-val">${val}</span>
      </div>`;
    }).join('');

    const esp = (p.especialidades||[]).map(e =>
      `<span class="tag-item">${e}</span>`).join('');
    const aero = (p.aeronaves||[]).map(a =>
      `<span class="tag-item">${a.modelo||a}</span>`).join('');
    const lastMission = p.ultima_missao
      ? `<span class="pilot-meta-item"><i class="fa-solid fa-location-crosshairs" style="color:var(--tac-green)"></i>${p.ultima_missao.data_voo} · ${p.ultima_missao.aeronave}</span>`
      : '';

    return `
    <div class="pilot-card" id="card-${p.id}" onclick="toggleCard(${p.id})">
      <div class="pilot-card-header">
        <div class="rank-badge ${rankCls}">${rankLabel}</div>
        ${p.foto_base64 && p.foto_base64.startsWith('data:')
          ? `<img class="pilot-thumb" src="${p.foto_base64}" alt="">`
          : `<div class="pilot-thumb-placeholder">${initials(p.nome)}</div>`}
        <div class="pilot-info-col">
          <div class="pilot-name">${p.nome}</div>
          <div class="pilot-meta">
            <span class="pilot-meta-item"><i class="fa-solid fa-location-dot"></i>${p.base}</span>
            <span class="pilot-meta-item"><i class="fa-solid fa-calendar"></i>${p.anos_experiencia}a</span>
            ${lastMission}
          </div>
        </div>
        <div class="cert-badges">${certsHtml}</div>
        <div class="hours-col">
          <div class="hours-val">${Math.round(p.horas_voo)}</div>
          <div class="hours-label">h.voo</div>
        </div>
        <div class="incident-col">
          ${p.num_incidentes === 0
            ? `<span class="incident-ok">◉ NIL</span>`
            : `<span class="incident-bad">${p.num_incidentes}</span>`}
        </div>
        <span class="nivel-badge nivel-${p.nivel}">${p.nivel}</span>
        <div class="score-col">
          <div class="score-bar-wrap">
            <div class="score-bar-bg"><div class="score-bar-fill" style="width:${p.score}%;background:${scoreColor}"></div></div>
            <span class="score-num" style="color:${scoreColor}">${p.score}</span>
            <span class="trend-icon ${trendCls}">${trendIcon}</span>
          </div>
        </div>
        <i class="fa-solid fa-chevron-down expand-icon"></i>
      </div>
      <div class="pilot-detail">
        <div style="display:flex;justify-content:flex-end;margin-bottom:12px">
          ${getInsigniaHTML(p.nivel, true)}
        </div>
        <div class="detail-grid">
          <div class="detail-stat"><div class="dv">${Math.round(p.horas_voo).toLocaleString('pt-BR')}</div><div class="dl">Horas de voo</div></div>
          <div class="detail-stat"><div class="dv">${Math.round(p.anos_experiencia)}</div><div class="dl">Anos exp.</div></div>
          <div class="detail-stat"><div class="dv" style="color:${p.num_incidentes===0?'var(--tac-green)':'var(--red-alert)'}">${p.num_incidentes}</div><div class="dl">Incidentes</div></div>
          <div class="detail-stat"><div class="dv">${(p.certificacoes||[]).length}</div><div class="dl">Certs</div></div>
          <div class="detail-stat"><div class="dv">${(p.aeronaves||[]).length}</div><div class="dl">Aeronaves</div></div>
          <div class="detail-stat"><div class="dv" style="color:${scoreColor}">${p.score}</div><div class="dl">Score</div></div>
        </div>
        <div class="detail-cols">
          <div>
            <div class="detail-section-title"><i class="fa-solid fa-sliders"></i> Competências</div>
            <div class="comp-bars">${compBars}</div>
            ${esp ? `<div class="detail-section-title" style="margin-top:16px"><i class="fa-solid fa-star"></i> Especialidades</div><div class="tags-row">${esp}</div>` : ''}
          </div>
          <div>
            <div class="detail-section-title"><i class="fa-solid fa-drone"></i> Aeronaves hab.</div>
            <div class="tags-row">${aero}</div>
            ${p.ultima_missao ? `
              <div class="detail-section-title" style="margin-top:16px"><i class="fa-solid fa-satellite"></i> Última missão</div>
              <div style="font-family:var(--mono);font-size:11px;color:var(--txt-sec);line-height:1.8">
                <div>DATA: <span style="color:var(--tac-green)">${p.ultima_missao.data_voo}</span></div>
                <div>AERONAVE: <span style="color:var(--tac-green)">${p.ultima_missao.aeronave}</span></div>
                <div>OP: <span style="color:var(--tac-green)">${p.ultima_missao.tipo_operacao||'—'}</span></div>
                <div>COORD: <span style="color:var(--tac-green)">${p.ultima_missao.lat_missao?.toFixed(4)}, ${p.ultima_missao.lon_missao?.toFixed(4)}</span></div>
              </div>` : ''}
          </div>
        </div>
        <div class="detail-actions">
          <button class="btn-tac" onclick="event.stopPropagation();window.location='piloto.html?id=${p.id}'">
            <i class="fa-solid fa-user"></i> Full Profile
          </button>
          <button class="btn-tac" onclick="event.stopPropagation();openVooModal(${p.id})">
            <i class="fa-solid fa-plus"></i> Log Flight
          </button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function toggleCard(id) {
  document.getElementById(`card-${id}`).classList.toggle('expanded');
}

function populatePilotoSelect() {
  const sel = document.getElementById('vPiloto');
  allPilotos.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = `${p.nome} · ${p.base}`;
    sel.appendChild(opt);
  });
}

function openVooModal(pilotoId) {
  openModal('modalVoo');
  if (pilotoId) document.getElementById('vPiloto').value = pilotoId;
}

document.getElementById('filterChips').addEventListener('click', e => {
  const btn = e.target.closest('.chip');
  if (!btn) return;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  currentFilter = btn.dataset.filter;
  renderRanking();
});

document.getElementById('searchInput').addEventListener('input', e => {
  currentSearch = e.target.value;
  renderRanking();
});

document.getElementById('sortSelect').addEventListener('change', e => {
  currentSort = e.target.value;
  renderRanking();
});

function openModal(id) { document.getElementById(id).style.display='flex'; }
function closeModal(id) { document.getElementById(id).style.display='none'; }

document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target===o) o.style.display='none'; });
});

async function criarPiloto() {
  const body = {
    nome: document.getElementById('pNome').value.trim(),
    matricula: document.getElementById('pMatricula').value.trim(),
    base: document.getElementById('pBase').value.trim(),
    data_admissao: document.getElementById('pAdmissao').value,
    contato_email: document.getElementById('pEmail').value.trim()||null,
    lat_base: parseFloat(document.getElementById('pLat').value)||null,
    lon_base: parseFloat(document.getElementById('pLon').value)||null,
  };
  if (!body.nome||!body.matricula||!body.base||!body.data_admissao) {
    showToast('MISSING REQUIRED FIELDS','error'); return;
  }
  try {
    const res = await fetch(`${API}/pilotos/`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if (!res.ok) { const e=await res.json(); throw new Error(e.detail||'Error'); }
    closeModal('modalPiloto');
    showToast('PILOT REGISTERED · OK','success');
    await fetchRanking();
  } catch(e) { showToast(e.message,'error'); }
}

async function registrarVoo() {
  const body = {
    piloto_id: parseInt(document.getElementById('vPiloto').value),
    data_voo: document.getElementById('vData').value,
    duracao_min: parseInt(document.getElementById('vDuracao').value),
    aeronave: document.getElementById('vAeronave').value,
    tipo_operacao: document.getElementById('vTipo').value,
    condicao_meteo: document.getElementById('vMeteo').value,
    voo_noturno: document.getElementById('vNoturno').checked,
    voo_sobre_agua: document.getElementById('vAgua').checked,
    lat_missao: parseFloat(document.getElementById('vLat').value)||null,
    lon_missao: parseFloat(document.getElementById('vLon').value)||null,
  };
  if (!body.piloto_id||!body.data_voo||!body.duracao_min) {
    showToast('MISSING REQUIRED FIELDS','error'); return;
  }
  try {
    const res = await fetch(`${API}/voos/`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if (!res.ok) throw new Error('LOG FAILED');
    closeModal('modalVoo');
    showToast('FLIGHT LOGGED · OK','success');
    await fetchRanking();
  } catch(e) { showToast(e.message,'error'); }
}

function showToast(msg, type='') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type} show`;
  setTimeout(()=>t.classList.remove('show'), 3500);
}

document.getElementById('vData').value = new Date().toISOString().split('T')[0];
fetchRanking();

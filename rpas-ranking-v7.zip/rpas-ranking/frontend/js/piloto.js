const API = 'http://localhost:8000/api';
const params = new URLSearchParams(location.search);
const PILOTO_ID = parseInt(params.get('id'));

const COMP_COLORS = {
  tecnica_voo:'#4A9EFF', seguranca:'#00D4FF', regulatorio:'#B89FFF',
  trabalho_equipe:'#FFB700', adaptabilidade:'#FF8C00', equipamentos:'#4AFFD4'
};
const COMP_LABELS = {
  tecnica_voo:'Técnica de voo', seguranca:'Segurança', regulatorio:'Regulatório',
  trabalho_equipe:'Trab. equipe', adaptabilidade:'Adaptabilidade', equipamentos:'Equipamentos'
};
const COMP_WEIGHTS = {tecnica_voo:.25,seguranca:.25,regulatorio:.15,trabalho_equipe:.10,adaptabilidade:.15,equipamentos:.10};

let piloto=null, profileMap=null;

function updateClock(){
  const n=new Date(),pad=v=>String(v).padStart(2,'0'),el=document.getElementById('utcClock');
  if(el) el.textContent=`${pad(n.getUTCHours())}:${pad(n.getUTCMinutes())}:${pad(n.getUTCSeconds())} UTC`;
}
setInterval(updateClock,1000); updateClock();

function getScoreColor(s){return s>=90?'#FFB700':s>=80?'#4A9EFF':s>=65?'#00D4FF':'#5A8AAA'}
function initials(nome){return nome.split(' ').slice(0,2).map(x=>x[0]).join('')}

async function loadPiloto(){
  if(!PILOTO_ID){document.getElementById('profileContent').innerHTML='<div class="empty-state">No pilot ID.</div>';return}
  try{
    const res=await fetch(`${API}/pilotos/${PILOTO_ID}`);
    if(!res.ok) throw new Error('Pilot not found');
    piloto=await res.json();
    document.title=`${piloto.nome} · RPAS Offshore`;
    renderProfile();
  }catch(e){
    document.getElementById('profileContent').innerHTML=`<div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i>${e.message}</div>`;
  }
}

function renderProfile(){
  const p=piloto;
  const sc=getScoreColor(p.score);
  const hasPhoto=p.foto_base64&&p.foto_base64.startsWith('data:');
  const insHTML=getInsigniaHTML(p.nivel,true);

  const certsHtml=(p.certificacoes||[]).map(c=>{
    const key=c.tipo.replace(/\s/g,'-');
    return `<span class="cert-tag cert-${key}">${c.tipo}</span>`;
  }).join('');

  const compBars=Object.entries(COMP_LABELS).map(([k,label])=>{
    const val=p.competencias?.[k]??70;
    return `<div class="comp-row">
      <span class="comp-label">${label}</span>
      <div class="comp-bar-bg"><div class="comp-bar-fill" style="width:${val}%;background:${COMP_COLORS[k]}"></div></div>
      <span class="comp-val" style="color:${COMP_COLORS[k]}">${val}</span>
    </div>`;
  }).join('');

  const vooRows=(p.historico_voos||[]).slice(0,12).map(v=>`
    <div class="voo-row">
      <span class="voo-date">${v.data_voo}</span>
      <span class="voo-aeronave">${v.aeronave}</span>
      <span style="font-family:var(--mono);font-size:10px;color:var(--txt-dim)">${v.tipo_operacao||'—'}</span>
      ${v.voo_noturno?'<span style="font-family:var(--mono);font-size:9px;color:#00D4FF;border:1px solid rgba(0,212,255,.3);padding:1px 5px">NITE</span>':''}
      <span class="voo-dur">${(v.duracao_min/60).toFixed(1)}h</span>
    </div>`).join('')||'<div class="empty-state" style="padding:1rem;font-size:11px">// NO RECORDS</div>';

  const incRows=(p.incidentes_detalhes||[]).map(i=>`
    <div class="inc-row inc-${i.severidade}">
      <div style="display:flex;justify-content:space-between">
        <span class="inc-tipo">${(i.tipo||'').toUpperCase()} · SEV:${(i.severidade||'').toUpperCase()}</span>
        <span class="inc-data">${i.data_incidente}</span>
      </div>
      ${i.descricao?`<div class="inc-desc">${i.descricao}</div>`:''}
      ${i.acao_corretiva?`<div style="font-family:var(--mono);font-size:10px;color:#4A9EFF;margin-top:4px">▶ ${i.acao_corretiva}</div>`:''}
    </div>`).join('')||'<div class="empty-state" style="padding:.75rem;font-size:11px">◉ NIL INCIDENTS · CLEAN RECORD</div>';

  const esp=(p.especialidades||[]).map(e=>`<span class="tag-item">${e}</span>`).join('');
  const aero=(p.aeronaves||[]).map(a=>`<span class="tag-item">${a.modelo||a}</span>`).join('');
  const hasCoords=p.lat_base&&p.lon_base;
  const hasMission=p.ultima_missao?.lat_missao&&p.ultima_missao?.lon_missao;

  document.getElementById('profileContent').innerHTML=`

  <!-- ══════════════════════════════════════════
       HERO — layout em linha
  ══════════════════════════════════════════ -->
  <div style="
    display:grid;
    grid-template-columns:120px 1fr 200px;
    gap:0;
    background:var(--bg-surface);
    border:1px solid var(--border-mid);
    border-top:2px solid ${sc};
    margin-bottom:10px;
    box-shadow:0 0 32px rgba(74,158,255,.08);
  ">

    <!-- COLUNA A: foto -->
    <div style="
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      padding:24px 16px;gap:12px;
      border-right:1px solid var(--border-dim);
      background:var(--bg-base);
    ">
      <div class="photo-zone" id="photoZone" style="width:88px;height:88px">
        ${hasPhoto
          ? `<img class="photo-img" src="${p.foto_base64}" alt="${p.nome}" style="width:88px;height:88px">
             <div class="photo-overlay" onclick="triggerPhotoUpload()"><i class="fa-solid fa-camera"></i><span>Alterar</span></div>
             <button class="photo-remove" onclick="event.stopPropagation();removerFoto()"><i class="fa-solid fa-xmark"></i></button>`
          : `<div class="photo-avatar" onclick="triggerPhotoUpload()" style="width:88px;height:88px;font-size:28px">${initials(p.nome)}</div>
             <div class="photo-overlay" onclick="triggerPhotoUpload()"><i class="fa-solid fa-camera"></i><span>Foto</span></div>`
        }
      </div>
      <div onclick="triggerPhotoUpload()" style="font-family:var(--mono);font-size:9px;letter-spacing:.08em;color:var(--txt-dim);text-transform:uppercase;cursor:pointer;text-align:center">
        ${hasPhoto?'✎ alterar':'+ foto'}
      </div>
    </div>

    <!-- COLUNA B: identidade -->
    <div style="padding:24px 28px;display:flex;flex-direction:column;justify-content:center;gap:10px">
      <div style="font-family:var(--mono);font-size:10px;letter-spacing:.12em;color:var(--txt-dim);text-transform:uppercase">
        ${p.matricula} &nbsp;·&nbsp; ${p.empresa||'ALTAVE'}
      </div>
      <div style="font-family:var(--mono);font-size:24px;letter-spacing:.05em;color:var(--txt-primary);text-transform:uppercase;line-height:1.1">
        ${p.nome}
      </div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <span class="nivel-badge nivel-${p.nivel}">${p.nivel}</span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:5px">
        ${certsHtml}
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:16px;margin-top:2px">
        <span class="profile-meta-item"><i class="fa-solid fa-location-dot"></i>${p.base}</span>
        <span class="profile-meta-item"><i class="fa-solid fa-calendar"></i>${Math.round(p.anos_experiencia)} anos</span>
        ${p.contato_email?`<span class="profile-meta-item"><i class="fa-solid fa-envelope"></i>${p.contato_email}</span>`:''}
      </div>
    </div>

    <!-- COLUNA C: score + patente em boxes separados -->
    <div style="
      border-left:1px solid var(--border-dim);
      display:flex;flex-direction:column;
    ">

      <!-- box score -->
      <div style="
        flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
        padding:20px 24px;border-bottom:1px solid var(--border-dim);
        background:rgba(74,158,255,.03);
      ">
        <div style="font-family:var(--mono);font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:var(--txt-dim);margin-bottom:6px">
          OPERATOR SCORE
        </div>
        <div style="font-family:var(--mono);font-size:64px;font-weight:400;line-height:1;color:${sc};text-shadow:0 0 40px ${sc}55">
          ${p.score}
        </div>
        <div style="width:80%;height:2px;background:var(--border-dim);margin-top:10px;border-radius:1px">
          <div style="height:100%;width:${p.score}%;background:${sc};box-shadow:0 0 6px ${sc}88"></div>
        </div>
      </div>

      <!-- box patente — separado e centralizado -->
      <div style="
        display:flex;flex-direction:column;align-items:center;justify-content:center;
        padding:16px 24px;gap:0;
        background:rgba(255,183,0,.02);
      ">
        ${insHTML}
      </div>

    </div>
  </div>

  <!-- ══ KPI STRIP ══ -->
  <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:10px">
    <div class="detail-stat"><div class="dv" style="color:var(--blue)">${Math.round(p.horas_voo).toLocaleString('pt-BR')}</div><div class="dl">Horas de voo</div></div>
    <div class="detail-stat"><div class="dv" style="color:var(--cyan)">${p.voos_noturnos||0}</div><div class="dl">Voos noturnos</div></div>
    <div class="detail-stat"><div class="dv" style="color:${p.num_incidentes===0?'#4AFF91':'var(--red-alert)'}">${p.num_incidentes}</div><div class="dl">Incidentes</div></div>
    <div class="detail-stat"><div class="dv">${(p.certificacoes||[]).length}</div><div class="dl">Certificações</div></div>
    <div class="detail-stat"><div class="dv">${(p.aeronaves||[]).length}</div><div class="dl">Aeronaves hab.</div></div>
  </div>

  <!-- ══ MAPA ══ -->
  ${(hasCoords||hasMission)?`
  <div class="map-section" style="margin-bottom:10px">
    <div class="map-header">
      <div class="map-title"><i class="fa-solid fa-satellite"></i> Pilot Position Map</div>
      <div style="font-family:var(--mono);font-size:10px;color:var(--txt-dim)">
        ${p.lat_base?`BASE: ${p.lat_base.toFixed(4)}, ${p.lon_base.toFixed(4)}`:''}
        ${hasMission?` · LAST: ${p.ultima_missao.lat_missao.toFixed(4)}, ${p.ultima_missao.lon_missao.toFixed(4)}`:''}
      </div>
    </div>
    <div id="profileMap" style="height:240px"></div>
  </div>`:''}

  <!-- ══ CONTEÚDO ══ -->
  <div class="content-2col">
    <div>
      <div class="card"><div class="card-title"><i class="fa-solid fa-sliders"></i> Competências</div><div class="comp-bars">${compBars}</div></div>
      <div class="card"><div class="card-title"><i class="fa-solid fa-drone"></i> Aeronaves</div><div class="tags-row">${aero||'—'}</div></div>
      ${esp?`<div class="card"><div class="card-title"><i class="fa-solid fa-star"></i> Especialidades</div><div class="tags-row">${esp}</div></div>`:''}
    </div>
    <div>
      <div class="card"><div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> Flight Log</div>${vooRows}</div>
      <div class="card"><div class="card-title"><i class="fa-solid fa-triangle-exclamation"></i> Incident Records</div>${incRows}</div>
    </div>
  </div>`;

  if(hasCoords||hasMission){
    setTimeout(()=>{
      const center=hasCoords?[p.lat_base,p.lon_base]:[p.ultima_missao.lat_missao,p.ultima_missao.lon_missao];
      profileMap=L.map('profileMap',{center,zoom:7,attributionControl:false});
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{maxZoom:18}).addTo(profileMap);
      if(hasCoords){
        const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
          <circle cx="20" cy="20" r="14" fill="${sc}" fill-opacity=".12" stroke="${sc}" stroke-width="1.5"/>
          <circle cx="20" cy="20" r="5" fill="${sc}"/>
          <line x1="20" y1="2" x2="20" y2="12" stroke="${sc}" stroke-width="1.5" opacity=".6"/>
          <line x1="20" y1="28" x2="20" y2="38" stroke="${sc}" stroke-width="1.5" opacity=".6"/>
          <line x1="2" y1="20" x2="12" y2="20" stroke="${sc}" stroke-width="1.5" opacity=".6"/>
          <line x1="28" y1="20" x2="38" y2="20" stroke="${sc}" stroke-width="1.5" opacity=".6"/>
        </svg>`;
        L.marker([p.lat_base,p.lon_base],{icon:L.divIcon({html:svg,className:'',iconSize:[40,40],iconAnchor:[20,20]})})
          .bindPopup(`<div style="font-family:monospace;font-size:11px;background:#0C1525;color:#4A9EFF;padding:6px 10px;border:1px solid #1E3350">BASE · ${p.base}</div>`)
          .addTo(profileMap);
      }
      if(hasMission){
        const msvg=`<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28">
          <rect x="10" y="10" width="8" height="8" fill="#FFB700" transform="rotate(45 14 14)"/>
          <rect x="8" y="8" width="12" height="12" fill="none" stroke="#FFB700" stroke-width="1" opacity=".5" transform="rotate(45 14 14)"/>
        </svg>`;
        L.marker([p.ultima_missao.lat_missao,p.ultima_missao.lon_missao],{icon:L.divIcon({html:msvg,className:'',iconSize:[28,28],iconAnchor:[14,14]})})
          .bindPopup(`<div style="font-family:monospace;font-size:11px;background:#0C1525;color:#FFB700;padding:6px 10px;border:1px solid #1E3350">LAST MISSION · ${p.ultima_missao.data_voo}</div>`)
          .addTo(profileMap);
        if(hasCoords) L.polyline([[p.lat_base,p.lon_base],[p.ultima_missao.lat_missao,p.ultima_missao.lon_missao]],{color:'#4A9EFF',weight:1,opacity:.3,dashArray:'5,8'}).addTo(profileMap);
      }
    },150);
  }
  document.getElementById('photoFileInput').onchange=handlePhotoChange;
}

function triggerPhotoUpload(){document.getElementById('photoFileInput').click()}
function handlePhotoChange(e){
  const file=e.target.files[0];if(!file)return;
  if(file.size>2*1024*1024){showToast('IMAGE TOO LARGE · MAX 2MB','error');return}
  const r=new FileReader();
  r.onload=async ev=>{await uploadFoto(ev.target.result)};
  r.readAsDataURL(file);e.target.value='';
}
async function uploadFoto(base64){
  try{
    showToast('UPLOADING...','');
    const res=await fetch(`${API}/pilotos/${PILOTO_ID}/foto`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({foto_base64:base64})});
    if(!res.ok){const e=await res.json();throw new Error(e.detail||'Error')}
    showToast('PHOTO UPDATED · OK','success');await loadPiloto();
  }catch(e){showToast(e.message,'error')}
}
async function removerFoto(){
  if(!confirm('Remover foto?'))return;
  await fetch(`${API}/pilotos/${PILOTO_ID}/foto`,{method:'DELETE'});
  showToast('PHOTO REMOVED','success');await loadPiloto();
}

function openEditModal(){
  if(!piloto)return;
  document.getElementById('compForm').innerHTML=Object.entries(COMP_LABELS).map(([k,label])=>{
    const val=piloto.competencias?.[k]??70,pct=Math.round(COMP_WEIGHTS[k]*100);
    return `<div class="comp-edit-row">
      <span class="comp-edit-label">${label} <small style="color:var(--txt-dim)">(${pct}%)</small></span>
      <input type="range" min="0" max="100" value="${val}" id="comp-${k}"
        oninput="document.getElementById('val-${k}').textContent=this.value;document.getElementById('val-${k}').style.color='${COMP_COLORS[k]}'">
      <span class="comp-edit-val" id="val-${k}" style="color:${COMP_COLORS[k]}">${val}</span>
    </div>`;
  }).join('');
  openModal('modalEdit');
}
async function salvarCompetencias(){
  const body={};Object.keys(COMP_LABELS).forEach(k=>{body[k]=parseInt(document.getElementById(`comp-${k}`).value)});body.avaliado_por='Sistema';
  try{
    const res=await fetch(`${API}/pilotos/${PILOTO_ID}/competencias`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(!res.ok)throw new Error('Save failed');
    closeModal('modalEdit');showToast('SKILLS UPDATED · OK','success');await loadPiloto();
  }catch(e){showToast(e.message,'error')}
}
function openIncidenteModal(){document.getElementById('iData').value=new Date().toISOString().split('T')[0];openModal('modalIncidente')}
async function registrarIncidente(){
  const body={piloto_id:PILOTO_ID,data_incidente:document.getElementById('iData').value,tipo:document.getElementById('iTipo').value,severidade:document.getElementById('iSev').value,descricao:document.getElementById('iDesc').value.trim()||null,acao_corretiva:document.getElementById('iCorr').value.trim()||null};
  try{
    const res=await fetch(`${API}/incidentes/`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    if(!res.ok)throw new Error('Log failed');
    closeModal('modalIncidente');showToast('INCIDENT LOGGED · OK','success');await loadPiloto();
  }catch(e){showToast(e.message,'error')}
}

function openModal(id){document.getElementById(id).style.display='flex'}
function closeModal(id){document.getElementById(id).style.display='none'}
document.querySelectorAll('.modal-overlay').forEach(o=>{o.addEventListener('click',e=>{if(e.target===o)o.style.display='none'})});
function showToast(msg,type=''){const t=document.getElementById('toast');t.textContent=msg;t.className=`toast ${type} show`;setTimeout(()=>t.classList.remove('show'),3500)}

loadPiloto();

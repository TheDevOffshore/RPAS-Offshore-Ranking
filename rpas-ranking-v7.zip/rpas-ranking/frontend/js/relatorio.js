const API = 'http://localhost:8000/api';
const CHART_OPTS = {
  color: { grid:'rgba(74,255,145,.06)', tick:'#3D5C42', label:'#7A9B7E' }
};

async function loadRelatorio() {
  try {
    const [rRes, kRes] = await Promise.all([
      fetch(`${API}/relatorios/resumo`),
      fetch(`${API}/pilotos/ranking`)
    ]);
    const resumo = await rRes.json();
    const ranking = await kRes.json();
    renderRelatorio(resumo, ranking.pilotos);
  } catch(e) {
    document.getElementById('relatorioContent').innerHTML='<div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i>Connection failed.</div>';
  }
}

const gridColor = 'rgba(74,255,145,.06)';
const tickColor = '#3D5C42';

function renderRelatorio(resumo, pilotos) {
  const el = document.getElementById('relatorioContent');
  el.innerHTML = `
    <div class="kpi-grid" style="margin-bottom:1.5rem">
      <div class="kpi-card kpi-hi"><div class="kpi-label">Active Pilots</div><div class="kpi-value">${resumo.total_pilotos}</div><div class="kpi-sub">br-offshore fleet</div></div>
      <div class="kpi-card"><div class="kpi-label">Total Fleet Hours</div><div class="kpi-value">${Math.round(resumo.total_horas_frota).toLocaleString('pt-BR')}</div><div class="kpi-sub">registered</div></div>
      <div class="kpi-card"><div class="kpi-label">Flights Logged</div><div class="kpi-value">${resumo.total_voos_registrados}</div><div class="kpi-sub">total records</div></div>
      <div class="kpi-card kpi-alert"><div class="kpi-label">Incidents Total</div><div class="kpi-value">${resumo.total_incidentes}</div><div class="kpi-sub">on record</div></div>
      <div class="kpi-card"><div class="kpi-label">Certifications</div><div class="kpi-value">${resumo.total_certificacoes}</div><div class="kpi-sub">active</div></div>
    </div>
    <div class="content-2col" style="margin-bottom:1.25rem">
      <div class="chart-wrap">
        <div class="detail-section-title"><i class="fa-solid fa-chart-pie"></i> Pilot Level Distribution</div>
        <div class="chart-canvas-wrap"><canvas id="chartNivel" role="img" aria-label="Distribuição de pilotos por nível">Distribuição: Elite, Sênior, Pleno, Júnior.</canvas></div>
      </div>
      <div class="chart-wrap">
        <div class="detail-section-title"><i class="fa-solid fa-location-dot"></i> Pilots by Base</div>
        <div class="chart-canvas-wrap"><canvas id="chartBase" role="img" aria-label="Pilotos por base">Pilotos por base operacional.</canvas></div>
      </div>
    </div>
    <div class="chart-wrap" style="margin-bottom:1.25rem">
      <div class="detail-section-title"><i class="fa-solid fa-trophy"></i> Score vs. Flight Hours · All Pilots</div>
      <div class="chart-canvas-wrap" style="height:300px"><canvas id="chartScore" role="img" aria-label="Score versus horas de voo">Score e horas dos pilotos.</canvas></div>
    </div>
  `;

  Chart.defaults.color = '#7A9B7E';
  Chart.defaults.borderColor = 'rgba(74,255,145,.06)';

  const nv = resumo.distribuicao_nivel;
  new Chart(document.getElementById('chartNivel'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(nv),
      datasets: [{
        data: Object.values(nv),
        backgroundColor: ['rgba(255,183,0,.7)','rgba(74,255,145,.7)','rgba(91,192,248,.7)','rgba(122,155,126,.3)'],
        borderColor: ['#FFB700','#4AFF91','#5BC0F8','#3D5C42'],
        borderWidth: 1,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position:'bottom', labels: { font:{size:11,family:'Share Tech Mono'}, padding:12, color:'#7A9B7E' } }
      }
    }
  });

  const bases = resumo.pilotos_por_base;
  new Chart(document.getElementById('chartBase'), {
    type: 'bar',
    data: {
      labels: bases.map(b=>b.base),
      datasets: [{
        label: 'Pilotos',
        data: bases.map(b=>b.n),
        backgroundColor: 'rgba(74,255,145,.15)',
        borderColor: '#4AFF91',
        borderWidth: 1,
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend:{display:false} },
      scales: {
        y: { beginAtZero:true, ticks:{stepSize:1,color:tickColor,font:{family:'Share Tech Mono',size:10}}, grid:{color:gridColor} },
        x: { ticks:{autoSkip:false,maxRotation:30,color:tickColor,font:{family:'Share Tech Mono',size:10}}, grid:{color:gridColor} }
      }
    }
  });

  new Chart(document.getElementById('chartScore'), {
    type: 'bar',
    data: {
      labels: pilotos.map(p=>p.nome.split(' ')[0].toUpperCase()),
      datasets: [
        {
          label: 'Score',
          data: pilotos.map(p=>p.score),
          backgroundColor: pilotos.map(p=>{
            if(p.score>=90) return 'rgba(255,183,0,.6)';
            if(p.score>=80) return 'rgba(74,255,145,.6)';
            if(p.score>=65) return 'rgba(91,192,248,.6)';
            return 'rgba(122,155,126,.4)';
          }),
          borderColor: pilotos.map(p=>{
            if(p.score>=90) return '#FFB700';
            if(p.score>=80) return '#4AFF91';
            if(p.score>=65) return '#5BC0F8';
            return '#7A9B7E';
          }),
          borderWidth: 1,
          yAxisID: 'y1'
        },
        {
          label: 'Horas de voo',
          data: pilotos.map(p=>Math.round(p.horas_voo)),
          type: 'line',
          borderColor: 'rgba(74,255,145,.4)',
          backgroundColor: 'transparent',
          tension: 0.3,
          pointBackgroundColor: '#4AFF91',
          pointRadius: 4,
          borderDash: [4,4],
          yAxisID: 'y2'
        }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { labels:{ font:{size:11,family:'Share Tech Mono'}, color:'#7A9B7E', padding:12 } }
      },
      scales: {
        y1: { position:'left', min:0, max:100,
          title:{display:true,text:'Score',color:'#3D5C42',font:{family:'Share Tech Mono',size:10}},
          ticks:{color:tickColor,font:{family:'Share Tech Mono',size:10}}, grid:{color:gridColor} },
        y2: { position:'right', beginAtZero:true,
          title:{display:true,text:'Horas',color:'#3D5C42',font:{family:'Share Tech Mono',size:10}},
          ticks:{color:tickColor,font:{family:'Share Tech Mono',size:10}}, grid:{drawOnChartArea:false} },
        x: { ticks:{autoSkip:false,color:tickColor,font:{family:'Share Tech Mono',size:10}}, grid:{color:gridColor} }
      }
    }
  });
}

loadRelatorio();
